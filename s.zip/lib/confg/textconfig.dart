class TextConfig {
  TextConfig._();
  static var appName = "Mobiz Sales";
  static var logo = "Assets/Images/main logo.png";
}

// class ProductsModel {
//   String? status;
//   Result? result;
//
//   ProductsModel({this.status, this.result});
//
//   ProductsModel.fromJson(Map<String, dynamic> json) {
//     status = json['status'];
//     result =
//         json['result'] != null ? new Result.fromJson(json['result']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['status'] = this.status;
//     if (this.result != null) {
//       data['result'] = this.result!.toJson();
//     }
//     return data;
//   }
// }
//
// class Result {
//   List<Data>? data;
//   bool? success;
//   List<String>? messages;
//
//   Result({this.data, this.success, this.messages});
//
//   Result.fromJson(Map<String, dynamic> json) {
//     if (json['data'] != null) {
//       data = <Data>[];
//       json['data'].forEach((v) {
//         data!.add(new Data.fromJson(v));
//       });
//     }
//     success = json['success'];
//     messages = json['messages'].cast<String>();
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.data != null) {
//       data['data'] = this.data!.map((v) => v.toJson()).toList();
//     }
//     data['success'] = this.success;
//     data['messages'] = this.messages;
//     return data;
//   }
// }
//
// class Data {
//   int? itemId;
//   int? quandity;
//   List<Products>? products;
//
//   Data({this.itemId, this.quandity, this.products});
//
//   Data.fromJson(Map<String, dynamic> json) {
//     itemId = json['item_id'];
//     quandity = json['quandity'];
//     if (json['products'] != null) {
//       products = <Products>[];
//       json['products'].forEach((v) {
//         products!.add(new Products.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['item_id'] = this.itemId;
//     data['quandity'] = this.quandity;
//     if (this.products != null) {
//       data['products'] = this.products!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Products {
//   int? id;
//   String? code;
//   String? name;
//
//   Products({this.id, this.code, this.name});
//
//   Products.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     code = json['code'];
//     name = json['name'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     data['code'] = this.code;
//     data['name'] = this.name;
//     return data;
//   }
// }
